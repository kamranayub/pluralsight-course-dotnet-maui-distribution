using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Mac;

namespace UITests;

public static class AppiumExtensions
{
    private const string MacDriverCommandClick = "macos: click";

    /// <summary>
    /// Wraps the Click command with an overload that uses the element's location
    /// </summary>
    /// <param name="element"></param>
    /// <param name="exact">Whether or not to click at the element's location (depends on driver)</param>
    /// <see href="https://github.com/appium/appium-mac2-driver?tab=readme-ov-file#macos-click"/>
    public static void Click(this AppiumElement element, bool exact = false) {
        if (exact && element.WrappedDriver is MacDriver macDriver) {
            macDriver.ExecuteScript(MacDriverCommandClick, 
                new Dictionary<string, object>() {
                    {"x", element.Location.X},
                    {"y", element.Location.Y}
            });
        } else {
            element.Click();
        }
    }
}
