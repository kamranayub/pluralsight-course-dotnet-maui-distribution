﻿namespace UITests;

public class GameTests : GameBaseTests
{
    public GameTests(AppiumFixture appium) : base(appium)
    {
        ResetGame();
    }

    [Fact]
    public void AppCanPlayTwoPlayerGameToTheEnd()
    {
        AddPlayer("Automation Player 1");
        AddPlayer("Automation Player 2");

        Move[] player1moves = [
            new Move(1, 5),
            new Move(3, 3),
            new Move(6, 4),
            new Move(10),   // Strike
            new Move(6, 4), // Spare
            new Move(4, 0),
            new Move(1, 2),
            new Move(7, 3),
            new Move(0, 0),       // Gutter
            new Move(10, 10, 10), // Turkey
        ];

        PlayMoves(player1moves, player1moves);
        
        var playerNames = FindAllByAutomationId("PlayerNameLabel");
        var playerScores = FindAllByAutomationId("PlayerScoreLabel");

        Assert.NotEmpty(playerNames);
        Assert.NotEmpty(playerScores);

        Assert.Equal("Automation Player 1", playerNames.ElementAt(0).Text);
        Assert.Equal("113", playerScores.ElementAt(0).Text);

        Assert.Equal("Automation Player 2", playerNames.ElementAt(1).Text);
        Assert.Equal("113", playerScores.ElementAt(1).Text);
    }

    private void PlayMoves(params Move[][] moves) {
        var turns = new List<Tuple<Move, Move>>();

        for (var i = 0; i < moves[0].Length; i++) {
            turns.Add(Tuple.Create(moves[0][i], moves[1][i]));
        }

        for (var i = 0; i < turns.Count; i++) {
            PlayMove(turns[i].Item1, 0, i);
            PlayMove(turns[i].Item2, 1, i);
        }
    }

    private void PlayMove(Move move, int player, int frame) {
        int frameIndex = (10 * player) + frame;

        FindAllByAutomationId("BowlingFrameBall1").ElementAt(frameIndex).Click(exact: true);
        FindAllByAutomationId("PinButton").ElementAt(move.Ball1).Click();

        if (move.Ball2 != null) {
            FindAllByAutomationId("BowlingFrameBall2").ElementAt(frameIndex).Click(exact: true);
            FindAllByAutomationId("PinButton").ElementAt(move.Ball2.Value).Click();
        }

        if (move.Ball3 != null) {
            FindAllByAutomationId("BowlingFrameBall3").ElementAt(player).Click(exact: true);
            FindAllByAutomationId("PinButton").ElementAt(move.Ball3.Value).Click();
        }
    }

    private record Move(int Ball1, int? Ball2 = null, int? Ball3 = null);
}