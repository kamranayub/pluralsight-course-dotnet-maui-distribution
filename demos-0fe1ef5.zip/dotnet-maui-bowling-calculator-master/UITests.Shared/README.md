﻿## UI Tests

These tests use Appium to execute E2E UI automation tests.

### Prerequisites

* [Node.js](https://nodejs.org/): needed to run Appium
* Appium version 2.0+
* Appium Drivers
  * UIAutomator2 for testing your Android app (can be used on both macOS and Windows)
  * XCUITest for testing your iOS app (only available on macOS)
  * Mac2 for testing your macOS app (only available on macOS)
    * For macOS also [Carthage](https://github.com/Carthage/Carthage) is needed
  * Windows for testing your Windows app (only available on Windows)
* For Windows install [WinAppDriver](https://github.com/microsoft/WinAppDriver) make sure to use version 1.2.1. Other versions might not work.

### Appium Commands

**Quick Install**

```sh
npm install -g appium
appium --help
appium driver list
```

My driver list as of March 2025 is:

```sh
✔ Listing available drivers
- uiautomator2@3.9.5 [installed (npm)]
- espresso@3.5.2 [installed (npm)]
- windows@3.1.3 [installed (npm)]
- xcuitest [not installed]
- mac2 [not installed]
- safari [not installed]
- gecko [not installed]
- chromium [not installed]
```

**On Windows:**

```sh
appium driver install --source=npm appium-windows-driver      # Windows
appium driver install uiautomator2                            # Android
appium driver install espresso                                # Android (optional)
```

> [!WARNING]
> The `install-wad` driver script doesn't seem to work as documented. I recommend 
> installing [WinAppDriver v1.2.1](https://github.com/microsoft/WinAppDriver/releases/tag/v1.2.1)
> directly from its GitHub releases page.


See [appium-windows-driver](https://github.com/appium/appium-windows-driver) for more details on the Windows driver.

> [!NOTE]
> As of the course recording in March 2025, I was using `appium-windows-driver@3` and not `@4` yet.
> I wanted to ensure the stability of the recordings so I didn't upgrade the project yet.

You will also need the Registered App ID, which you can find in the `bin\Debug\net9.0-windows<version>\win10-x64\AppX\vs.appxrecipe` file. Look for the `RegisterUserModeAppID` property value.

To get it via PowerShell, you can run the following command from the `./App` directory:

```powershell
(gc .\bin\Debug\net9.0-windows10.0.26100.0\win10-x64\AppX\vs.appxrecipe) | ^
  ? { $_ -match 'RegisteredUserModeAppID' }
```

**On macOS:**

```sh
appium driver install xcuitest     # iOS / tvOS
appium driver install mac2         # macOS
appium driver install uiautomator2 # Android
```

## Running the Tests

For the best results on your local machine:

1. Build the full solution
2. Run (with or without debugging) the App on every target platform **first**
3. Run the Appium platform tests

> [!NOTE]
> The Appium projects are configured to use the bundle/package ID when launching the
> app, which means it needs to be on the device first. You deploy it beforehand
> by running the app. **You need to re-run/deploy the app anytime you change it
> before expecting new functionality to be reflected in the test run.**

You run the Appium tests in Visual Studio using the **Test Explorer**, and on
Visual Studio Code using the **Testing** panel (part of C# Dev Kit extension).

## Managing Environment Variables

Running Appium in .NET requires some environment variables and settings:

- `ANDROID_HOME` to be set to the path of the Android SDK
- `node.exe` to be in the PATH

You can set these at the system/user level, or use the `.runsettings` file(s) to set them for the test run. Each
Appium platform `.csproj` file sets the `RunSettings` property to the appropriate `.runsettings` file stored in
`UITests.Shared/`.

> [!NOTE]
> Visual Studio doesn't seem to pick up changes to `.runsettings` files unless you restart Visual Studio.

On my machine, I use [fnm](https://github.com/Schniz/fnm) to manage Node versions. This does not add `node.exe` to my PATH. 
To have the tests run successfully, I had to add `PATH` to my `.runsettings` file.

Using PowerShell, you can get the path using `(which node).Source`. This needs to be updated whenever you switch Node versions.

> [!WARNING]
> Setting the `NODE_BINARY_PATH` environment variable did not work for me. Some of the Appium utility code seems to depend on `node.exe` being
> in the PATH regardless of what the error message says.

## iOS and macOS Setup


The simulator works without additional prep. But for real device testing, there is. You can follow the Appium guides:

- https://appium.github.io/appium-xcuitest-driver/latest/preparation/
- https://appium.github.io/appium-xcuitest-driver/latest/preparation/real-device-config/
- https://appium.github.io/appium-xcuitest-driver/latest/preparation/prov-profile-basic-auto/

For this project, I am using the Automatic provisioning approach for the WDA (driver app).

> [!NOTE]
> Make sure you have your Apple account setup in XCode or the XCode build will fail.

The iOS Appium capabilities I am using are in the `AppiumSetup.cs` file for reference:

- `udid` is my real device ID which you can find in XCode Devices and Simulators window.
- `showXCodeLog` includes the XCode build log in the Appium server log, useful for troubleshooting
- `allowProvisioningDeviceRegistration` allows the Appium server to provision the WDA app on the device automatically


You optionally can use a `.xcconfig` instead of passing your signing key in the C# file, mine is in my user profile folder:

In `~/.xcconfig`:

```

```

> [!WARNING]
> The Appium XCUI driver guide says to use `Apple Developer` as the code sign identity but
> when I tried that, XCode build log error said to use `Apple Development`.

### Appium Server Logs

When troubleshooting the initial `xcodebuild`, I found it helpful to tail my Appium logfile which
is configured to be written to `~/.appium/log.log`:

```sh
tail -f ~/.appium/log.log
```

This will display the XCode build output as well as the Appium server logs.

## Debugging Layouts and Elements

When debugging UI tests, it can be helpful to see the layout of the app and the elements that are available. 
This can be done by using the [Appium Inspector](https://github.com/appium/appium-inspector) tool. 

This tool allows you to inspect the app and see the elements that are available. To use it with Visual Studio tests,
start the test run which launches the local Appium server. Then in the inspector, use "Attach to session" which will
automatically find the running Appium server and let you connect to it.

> [!NOTE]
> If you are paused on a breakpoint, the inspector will not load, so you have to be running the test to attach to it. This
> shouldn't be an issue if you start the Appium server separately in another process, it is a symptom of the
> the Appium server being started and stopped by the test run.

You may prefer using the native Android Layout Inspector within Android Studio. This can be used to inspect the layout
even while paused on a breakpoint.
