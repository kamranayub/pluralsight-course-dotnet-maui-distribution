﻿namespace UITests;

public class GameBaseTests : BaseTest
{
    public GameBaseTests(AppiumFixture appium) : base(appium)
    {
    }

    protected void ResetGame()
    {
        var resetGameButton = FindByAutomationId("ResetGameButton");
        if (resetGameButton.Enabled)
        {
            resetGameButton.Click();
            DismissAlert();
        }
    }

    protected void AddPlayer(string name) {
        FindByAutomationId("AddPlayerButton").Click();

        FindByAutomationId("AddPlayerInput").SendKeys(name);

        FindByAutomationId("AddPlayerSubmit").Click();
    }
}