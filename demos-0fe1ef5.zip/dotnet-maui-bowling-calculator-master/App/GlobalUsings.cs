﻿global using BowlingCalculator.Views;
global using BowlingCalculator.ViewModels;
global using BowlingCalculator.BowlingGame;
global using BowlingCalculator.Models;