﻿using Microsoft.Extensions.Logging;
using CommunityToolkit.Maui;
using MauiIcons.FontAwesome;
using MauiIcons.FontAwesome.Solid;
using MauiIcons.Core;
using Microsoft.Maui.LifecycleEvents;

namespace BowlingCalculator
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .UseFontAwesomeMauiIcons()
                .UseFontAwesomeSolidMauiIcons()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                })
                .ConfigureLifecycleEvents(lifecycle =>
                {
                    // Handle app links on Android when the app is launched or resumed
                    // See: https://learn.microsoft.com/en-us/dotnet/maui/android/app-links
                    // And: https://developer.android.com/training/app-links/deep-linking
#if ANDROID
                    lifecycle.AddAndroid(android =>
                    {
                        android.OnCreate((activity, bundle) =>
                        {
                            var action = activity.Intent?.Action;
                            var data = activity.Intent?.Data?.ToString();

                            if (action == Android.Content.Intent.ActionView && data is not null)
                            {
                                Task.Run(() => HandleAppLink(data));
                            }
                        });

                        android.OnNewIntent((activity, intent) =>
                        {
                            var action = intent?.Action;
                            var data = intent?.Data?.ToString();

                            if (action == Android.Content.Intent.ActionView && data is not null)
                            {
                                Task.Run(() => HandleAppLink(data));
                            }
                        });
                    });
#endif
                });

#if DEBUG
                    builder.Logging.AddDebug();
#endif

            CoreRegistration.Register(builder.Services);

            builder.Services.AddSingleton<AppShell>();


            // Temporary Workaround for url styled namespace in xaml
            // See: https://github.com/AathifMahir/MauiIcons?tab=readme-ov-file#workaround
            _ = new MauiIcon();

            return builder.Build();
        }

        static void HandleAppLink(string url)
        {
            if (Uri.TryCreate(url, UriKind.RelativeOrAbsolute, out var uri))
                App.Current?.SendOnAppLinkRequestReceived(uri);
        }
    }

}
