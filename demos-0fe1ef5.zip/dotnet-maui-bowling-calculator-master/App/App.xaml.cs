﻿using BowlingCalculator.Storage;

namespace BowlingCalculator
{
    public partial class App : Application
    {
        private readonly AppShell shell;
        private readonly ThemeStore _themeStore;

        public App(IServiceProvider provider)
        {
            InitializeComponent();

            // Workaround issue accessing Application Resources
            // See: https://github.com/dotnet/maui/issues/11485
            shell = provider.GetService<AppShell>()
                ?? throw new NullReferenceException($"Could not locate {nameof(AppShell)} using IServiceProvider");

            _themeStore = provider.GetService<ThemeStore>()
                ?? throw new NullReferenceException($"Could not locate {nameof(ThemeStore)} using IServiceProvider");
        }

        protected override Window CreateWindow(IActivationState? activationState)
        {
            return new Window(shell);
        }

        protected override void OnStart()
        {
            base.OnStart();

            LoadTheme();
        }

        private void LoadTheme()
        {
            var themePreference = _themeStore.GetThemePreference();
            Current.UserAppTheme = themePreference;
        }

        protected override async void OnAppLinkRequestReceived(Uri uri)
        {
            base.OnAppLinkRequestReceived(uri);

            // Navigate to the About page when the app link is received.
            if (uri.Host == "about")
            {
                await MainThread.InvokeOnMainThreadAsync(() => 
                    Shell.Current.GoToAsync(nameof(AboutView)));
            }
        }
    }
}