﻿using OpenQA.Selenium.Appium.Android;

namespace UITests;

public static class AndroidDeepLinkExtensions
{
    /// <summary>
    /// Navigates to a deep link URL in the Android application using the Appium UIAutomator2 driver.
    /// </summary>
    /// <param name="driver"></param>
    /// <returns></returns>
    /// <see href="https://github.com/appium/appium-uiautomator2-driver?tab=readme-ov-file#mobile-deeplink" />
    public static void GoToDeepLink(this AndroidDriver driver, Uri uri)
    {
        driver.ExecuteScript("mobile: deepLink", new Dictionary<string, object>
        {
            { "url", uri.ToString() }
        });
    }

}
