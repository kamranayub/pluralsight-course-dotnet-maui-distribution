﻿using OpenQA.Selenium.Appium.Android;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UITests;

public enum AndroidDarkModeValue { Yes, No, Auto, CustomSchedule, CustomBedtime }

public static class AndroidDarkModeExtensions
{
    /// <summary>
    /// Gets the current dark mode setting of the Android device.
    /// </summary>
    /// <param name="driver"></param>
    /// <returns></returns>
    /// <see href="https://github.com/appium/appium-uiautomator2-driver?tab=readme-ov-file#mobile-getuimode" />
    public static AndroidDarkModeValue GetDarkMode(this AndroidDriver driver)
    {
        var result = driver.ExecuteScript("mobile: getUiMode", new Dictionary<string, object>
        {
            { "mode", "night" },
        });

        return result switch
        {
            "yes" => AndroidDarkModeValue.Yes,
            "no" => AndroidDarkModeValue.No,
            "auto" => AndroidDarkModeValue.Auto,
            "custom_schedule" => AndroidDarkModeValue.CustomSchedule,
            "custom_bedtime" => AndroidDarkModeValue.CustomBedtime,
            _ => throw new NotSupportedException($"Unknown dark mode value: {result}"),
        };
    }

    /// <summary>
    /// Gets the current dark mode setting of the Android device.
    /// </summary>
    /// <param name="driver"></param>
    /// <returns></returns>
    /// <see href="https://github.com/appium/appium-uiautomator2-driver?tab=readme-ov-file#mobile-setuimode" />
    public static void SetDarkMode(this AndroidDriver driver, AndroidDarkModeValue value)
    {
        var modeValue = value switch
        {
            AndroidDarkModeValue.Yes => "yes",
            AndroidDarkModeValue.No => "no",
            AndroidDarkModeValue.Auto => "auto",
            AndroidDarkModeValue.CustomSchedule => "custom_schedule",
            AndroidDarkModeValue.CustomBedtime => "custom_bedtime",
            _ => throw new NotSupportedException($"Unknown dark mode value: {value}"),
        };
        
        driver.ExecuteScript("mobile: setUiMode", new Dictionary<string, object>
        {
            { "mode", "night" },
            { "value", modeValue }
        });
    }
}
