﻿using OpenQA.Selenium.Appium.Android;

namespace UITests;

public class SystemThemeTests : BaseTest, IDisposable
{
    public SystemThemeTests(AppiumFixture fixture) : base(fixture)
    {
        Android = (AndroidDriver)App;
        InitialDarkModeValue = Android.GetDarkMode();

        Android.GoToDeepLink(new Uri("bowlingcalculator://about"));
    }

    public AndroidDriver Android { get; }
    public AndroidDarkModeValue InitialDarkModeValue { get; }

    [Fact]
    public void AppUsesDarkModeWhenSet()
    {
        Android.SetDarkMode(AndroidDarkModeValue.No);

        Assert.Equal("App Theme (Light)", 
            FindByAutomationId("AppThemePicker").GetAttribute("hint"));

        Android.SetDarkMode(AndroidDarkModeValue.Yes);

        Assert.Equal("App Theme (Dark)", 
            FindByAutomationId("AppThemePicker").GetAttribute("hint"));
    }

    public void Dispose()
    {
        Android.SetDarkMode(InitialDarkModeValue);
    }
}
