# The .NET MAUI Bowling Calculator App

This app was developed as a production-grade reference implementation for building .NET MAUI apps, and is featured as the demo app for my Pluralsight courses.

- [Testing .NET MAUI Apps](https://github.com/kamranayub/pluralsight-course-dotnet-maui-testing) (April 2025)
- Distributing .NET MAUI Apps (_June 2025_)

The intent for this app is to remain open source but also published to the app store, which I plan to maintain.

## Where to Find Notes

I will keep notes in `README.md` files under each project you can reference.

## Troubleshooting

### Pair to Mac Fails with Shell not found

Related error messages:

- An error occurred while generating the SSH keys. Please check that the environment is properly configured.
- Checking SSH keys... (then fails)
- The shell '' is currently not supported. Please change it to one of the supported shells in order to continue. Supported shells: bash, zsh, ksh, tcsh, sh, csh

Seems to be an issue with `printenv SHELL` command sent over SSH.

I tried most of the [troubleshooting steps](https://stackoverflow.com/questions/75082320/visual-studio-2019-pair-to-mac-stuck-at-checking-ssh-configuration) but nothing seemed to work.

In the end, restarting Windows seems to fix it. :disappointed: Restarting the Mac first did not fix it, but restart for good measure.

### Pair to Mac Fails with SDK not found

Related error messages:

- The connection cannot continue because the remote {iOS/Android} SDK was not found or is corrupted

You can try to reset the Xamarin agent on both Windows and macOS:

In Mac:

- Delete your `XMA` folder (under `~/Library/Caches/Xamarin`) from mac.

In Windows:

- Close VS.
- Delete `%localappdata%\Local\Xamarin\MonoTouch`.
- Delete `%localappdata%\Temp\Xamarin\XMA\Local`.

Then reopen Visual Studio pair to mac once more to check if the pair is successful.

> [!NOTE]
> This will delete your Xamarin SSH keys and will re-create them.

[source](https://developercommunity.visualstudio.com/t/Pair-to-mac-not-working-since-VS2022-upd/10566522?sort=newest)