﻿using BowlingCalculator.Converters;
using DeviceTests.Support;

namespace DeviceTests.Tests;

[Collection("ThemeTests")]
public class ScoreGridTextColorConverterTests : IAsyncLifetime
{
    [Fact]
    public async Task Convert_WhenScoreIsSpare_ReturnsTertiaryResourceIfLightAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Light));


        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert("/", null, null, null);
        Assert.Equal(Application.Current!.Resources["Tertiary"], result);
    }

    [Fact]
    public async Task Convert_WhenScoreIsStrike_ReturnsTertiaryResourceIfLightAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Light));

        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert("X", null, null, null);
        Assert.Equal(Application.Current!.Resources["Tertiary"], result);
    }

    [Fact]
    public async Task Convert_WhenScoreIsSpare_ReturnsTertiaryDarkResourceIfDarkAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Dark));


        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert("/", null, null, null);
        Assert.Equal(Application.Current!.Resources["TertiaryDark"], result);
    }

    [Fact]
    public async Task Convert_WhenScoreIsStrike_ReturnsTertiaryDarkResourceIfDarkAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Dark));

        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert("X", null, null, null);
        Assert.Equal(Application.Current!.Resources["TertiaryDark"], result);
    }

    [Fact]
    public async Task Convert_WhenRegularScore_ReturnsSecondaryResourceIfDarkAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Dark));

        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert(1, null, null, null);
        Assert.Equal(Application.Current!.Resources["Secondary"], result);
    }

    [Fact]
    public async Task Convert_WhenRegularScore_ReturnsPrimaryResourceIfLightAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Light));

        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert(1, null, null, null);
        Assert.Equal(Application.Current!.Resources["Primary"], result);
    }

    public Task InitializeAsync()
    {
        return Task.CompletedTask;
    }

    public async Task DisposeAsync()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Unspecified));
    }
}
