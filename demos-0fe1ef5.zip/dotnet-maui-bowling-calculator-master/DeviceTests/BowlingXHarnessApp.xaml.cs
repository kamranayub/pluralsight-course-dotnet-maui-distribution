﻿using DeviceRunners.XHarness.Maui;

namespace DeviceTests
{
    public partial class BowlingXHarnessApp : XHarnessApp
    {
        public BowlingXHarnessApp()
        {
            InitializeComponent();
        }
    }
}