﻿# Bowling Calculator Device Tests

This project provides **experimental** device tests for the Bowling Calculator app. The tests are written in C# and run on Android and iOS devices.

Tests will run in the Visual Test Runner or in the XHarness CLI.

## Installing XHarness

Follow the instructions in the [XHarness documentation](https://github.com/dotnet/xharness).

## Running XHarness

### For Android

Make sure that you have a physical device connected or the emulator started and running.

- arm64: Use `android-arm64`
- x86: Use `android-x64`

**Publish:**

```powershell
dotnet publish .\DeviceTests.csproj `
  -r android-x64 `
  -f net9.0-android `
  -c Release `
  -p:TestingMode=XHarness
```

**Run:**

This clears the artifacts directory and runs the XHarness Android test against the signed release APK, with a timeout of 30 seconds (the default is 900 seconds).

```powershell
 rm -r artifacts/; `
 xharness android test `
   --app bin/Release/net9.0-android/android-x64/publish/com.companyname.devicetests-Signed.apk `
   --package-name com.companyname.devicetests `
   --instrumentation devicerunners.xharness.maui.XHarnessInstrumentation `
   --output-directory artifacts `
   --timeout 30
```

> [!NOTE]
> Remember to have an arm64/x64-compatible emulator or device running!

### For iOS


**Publish:**

You can build for a physical device with `-r ios-arm64`:

```bash
dotnet build ./DeviceTests.csproj \
  -r ios-arm64 \
  -f net9.0-ios \
  -c Debug \
  -p:TestingMode=XHarness
```

Or the simulator using `-r iossimulator-arm64`:

```bash
dotnet build ./DeviceTests.csproj \
  -r iossimulator-arm64 \
  -f net9.0-ios \
  -c Debug \
  -p:TestingMode=XHarness
```

**Run:**

You can target `ios-device` for a physical device:

```bash
rm -rf artifacts; \
xharness apple test \
  --target ios-device \
  --app bin/Debug/net9.0-ios/ios-arm64/DeviceTests.app \
  --output-directory artifacts \
  --timeout 30

# test result file will be artifacts/xunit-test-ios-simulator-64-########_######.xml
```

or the simulator with `ios-simulator-64`:

```bash
rm -rf artifacts; \
xharness apple test \
  --target ios-simulator-64 \
  --app bin/Debug/net9.0-ios/iossimulator-arm64/DeviceTests.app \
  --output-directory artifacts \
  --timeout 30

# test result file will be artifacts/xunit-test-ios-simulator-64-########_######.xml
```

## Gotcha: Adding Core App Resources

The default `VisualRunnerApp` and `XHarnessApp` Application files packaged with `DeviceRunners` 
do not include the necessary resources for the Bowling Calculator app (under `Core\Resources\Styles`).

This means that you will need to override the two application entrypoint files with your 
own that merge in your app resources. Then, you can pass your custom app classes to `UseMauiApp`
in the `MauiProgram` builder.

Note that the merged dictionary only works with XAML-based `Source` attribute. Trying to programmatically
add the resources or use namespace instances (as the docs suggest) did not appear to work.

## Gotcha: Could not find instrumentation info

If you see this in the log output:

```
ActivityManager: Unable to find instrumentation info for: ComponentInfo{com.companyname.devicetests/devicerunners.xharness.maui.XHarnessInstrumentation} 
app_process: System.exit called, status: 1
AndroidRuntime: VM exiting with result code 1.
```

It just means you're missing the `DeviceRunners.XHarness.*` packages (which includes the Microsoft XHarness test runner).

## Gotcha: XHarness can't find physical iOS device?

Even with my physical iPhone device connected, `xharness apple state` didn't find it. However, after disabling "Connects via Network" and reattaching the cable, it started working. :shrug:

## Gotcha: Android XHarness Hangs / Doesn't Terminate

I ran into an issue with the XHarness Runner on Android hanging when running theme-related tests.

I narrowed it down by commenting out the tests in the `AboutViewTests` class, but discovered the root cause was in the `ScoreGridTextColorConverterTests` class.

The `ApplicationThemeExtensions.RequestThemeChangeAsync` was causing an issue that would wait forever for the `RequestedThemeChanged` to fire but in some cases it won't. Adding a timeout and being sure to clean up the event handler fixed the problem.

> [!TIP]
> Be sure to double check any `async/await` code and always be sure to set a timeout so the test doesn't hang forever. You can inspect the XHarness instrumentation log for any `DOTNET` lines to check if tests are passing/failing before the hang occurs. Pass a `--timeout 30` (30s) flag to `xharness test` otherwise the default timeout is 900 seconds.

## Credits

- The DeviceRunners packages are sourced from https://github.com/mattleibow/DeviceRunners
- Examples of device tests can be found at https://github.com/dotnet/maui/blob/main/src/Controls/tests/DeviceTests
