﻿using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml;

namespace BowlingCalculator.Platforms.Windows
{
    /// <summary>
    /// See: https://github.com/dotnet/maui/blob/main/src/Core/src/Platform/Windows/FrameworkElementExtensions.cs
    /// </summary>
    internal static class FrameworkElementExtensions
    {
        internal static T? GetDescendantByName<T>(this DependencyObject parent, string elementName) where T : DependencyObject
        {
            var myChildrenCount = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < myChildrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                if (child is T t && elementName.Equals(child.GetValue(FrameworkElement.NameProperty)))
                    return t;
                else if (child.GetDescendantByName<T>(elementName) is T tChild)
                    return tChild;
            }
            return null;
        }

        internal static T? GetFirstDescendant<T>(this DependencyObject element) where T : FrameworkElement
        {
            var count = VisualTreeHelper.GetChildrenCount(element);
            for (var i = 0; i < count; i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(element, i);

                if ((child as T ?? GetFirstDescendant<T>(child)) is T target)
                    return target;
            }
            return null;
        }
    }
}
