﻿using Microsoft.Maui.Platform;

namespace DeviceTests.Support;

public static class ViewExtensions
{
    /// <summary>
    /// Wraps the built-in IView.ToHandler(IMauiContext) method with a generic type helper.
    /// </summary>
    /// <typeparam name="THandler">The IPlatformViewHandler type you want to cast as</typeparam>
    /// <param name="view"></param>
    /// <param name="mauiContext"></param>
    /// <returns></returns>
    public static THandler ToHandler<THandler>(this IView view, IMauiContext mauiContext) where THandler : IPlatformViewHandler
    {
        return (THandler)view.ToHandler(mauiContext);
    }
}
