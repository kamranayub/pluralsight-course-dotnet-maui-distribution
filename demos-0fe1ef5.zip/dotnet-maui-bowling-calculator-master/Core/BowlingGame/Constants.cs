﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingCalculator.BowlingGame;

public class Constants
{
    public const int DefaultGameId = 1;
    public const int Frames = 10;
    public const int TotalPins = 10;
}