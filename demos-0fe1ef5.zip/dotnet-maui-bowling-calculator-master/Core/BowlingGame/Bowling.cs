﻿using System;
using System.Collections.ObjectModel;
using BowlingCalculator.BowlingGame.Messages;
using BowlingCalculator.Storage;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Messaging;

namespace BowlingCalculator.BowlingGame;

public class Bowling : ObservableObject, IRecipient<RequestAddPlayerMessage>, IRecipient<RequestGameResetMessage>, IRecipient<RequestGameLoadMessage>, IRecipient<Game.Turn>
{
    private readonly IMessenger _events;
    private bool _isEnded;
    private int _currentFrame;
    private BowlingPlayer? _currentPlayer;
    private bool _isInProgress;
    private ObservableCollection<BowlingPlayer> _players;

    public Bowling(IMessenger events)
    {
        if (events == null) throw new ArgumentNullException("events");

        _events = events;
        _events.RegisterAll(this, default(GameToken));

        Players = new ObservableCollection<BowlingPlayer>();
        CurrentFrame = 1;
    }

    public int Id => Constants.DefaultGameId;

    /// <summary>
    /// The players involved in the game
    /// </summary>
    public ObservableCollection<BowlingPlayer> Players { 
        get => _players;
        private set
        {
            if (_players == value) return;
            _players = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsStarted));
        }
    }

    /// <summary>
    /// The current frame
    /// </summary>
    public int CurrentFrame
    {
        get { return _currentFrame; }
        private set
        {
            if (value == _currentFrame) return;
            _currentFrame = value;
            OnPropertyChanged();
        }
    }

    /// <summary>
    /// The current player
    /// </summary>
    public BowlingPlayer? CurrentPlayer
    {
        get { return _currentPlayer; }
        private set
        {
            if (Equals(value, _currentPlayer)) return;
            _currentPlayer = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsStarted));
        }
    }


    public string? CurrentFrameSemanticHint
    {
        get
        {
            if (CurrentPlayer != null) {
                return $"Player '{CurrentPlayer.Name}' is on frame {CurrentFrame}";
            } else
            {
                return null;
            }
        }
    }


    /// <summary>
    /// Whether or not the game has ended (turns finished)
    /// </summary>
    public bool IsEnded
    {
        get { return _isEnded; }
        set
        {
            if (value.Equals(_isEnded)) return;
            _isEnded = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(IsStarted));
        }
    }

    /// <summary>
    /// Whether or not the game is in progress; at least one player has bowled
    /// </summary>
    public bool IsInProgress
    {
        get { return _isInProgress; }
        set
        {
            if (value.Equals(_isInProgress)) return;
            _isInProgress = value;
            OnPropertyChanged();
        }
    }

    /// <summary>
    /// Whether or the game has started; at least one player needs to be present or the game can be over
    /// </summary>
    public bool IsStarted
    {
        get { return CurrentPlayer != null || IsEnded; }
    }

    /// <summary>
    /// Add a new player to the game
    /// </summary>
    /// <param name="playerName"></param>
    /// <returns></returns>
    public BowlingPlayer AddPlayer(string playerName)
    {
        var newPlayer = new BowlingPlayer() { Name = playerName };

        // add player to game
        Players.Add(newPlayer);

        // game hasn't started
        if (!IsStarted)
        {
            CurrentPlayer = Players[0];
            CurrentPlayer.Frames.First().IsCurrentFrame = true;

            _events.Send(new Game.Started(), default(GameToken));
        }

        _events.Send(new Game.PlayerAdded(), default(GameToken));

        return newPlayer;
    }

    /// <summary>
    /// Throw a ball. State machine.
    /// </summary>
    /// <param name="pins"></param>
    public void Bowl(int pins)
    {
        if (CurrentPlayer == null || IsEnded) return;

        // Started
        if (!IsInProgress)
        {
            IsInProgress = true;

            _events.Send(new Game.InProgress(), default(GameToken));
        }

        // Take turn
        CurrentPlayer.Bowl(CurrentFrame, pins);

        // Update frame scores
        int? prevScore = 0;
        int prevCumulativeScore = 0;
        for (var i = 0; i < CurrentPlayer.Frames.Count; i++)
        {
            var frame = CurrentPlayer.Frames[i];
            int? score = frame.GetScore(CurrentPlayer.Frames);

            if (frame.IsDone() && prevScore != null && score != null)
            {
                frame.CumulativeScore = prevCumulativeScore + score;
            }

            prevScore = score;
            prevCumulativeScore += score.GetValueOrDefault();
        }

        // Update player scores
        CurrentPlayer.Score = CurrentPlayer.GetScore();

        bool isEndOfTurn = CurrentPlayer.Frames[CurrentFrame - 1].IsDone();
        bool isLastPlayer = Players.Last() == CurrentPlayer;

        if (CurrentFrame == Constants.Frames && isLastPlayer && isEndOfTurn)
        {
            // End game
            GameOver();
            return;
        }
        else if (isEndOfTurn && isLastPlayer)
        {
            // Advance frame
            NextFrame();
        }

        if (isEndOfTurn)
        {
            // Advance turn
            NextTurn();
        }

        _events.Send(new Game.Turn(GetState()), default(GameToken));
    }


    private void NextFrame()
    {
        CurrentFrame++;
    }

    private void NextTurn()
    {
        var curIndex = Players.IndexOf(CurrentPlayer);

        if (Players.ElementAtOrDefault(curIndex + 1) == null)
        {
            CurrentPlayer = Players[0];
        }
        else
        {
            CurrentPlayer = Players[curIndex + 1];
        }

        UpdateCurrentFrame();
    }

    private void GameOver()
    {
        IsEnded = true;
        UpdateCurrentFrame();

        _events.Send(new Game.Turn(GetState()), default(GameToken));
        _events.Send(new Game.Ended(GetState()), default(GameToken));
    }

    private void UpdateCurrentFrame()
    {
        foreach (var player in Players)
        {
            foreach (var frame in player.Frames)
            {
                frame.IsCurrentFrame = !IsEnded &&
                    CurrentFrame == frame.Index + 1 &&
                    CurrentPlayer == player;
            }

            player.OnFramesChanged();
        }
    }

    public BowlingState GetState()
    {
        return new BowlingState()
        {
            Id = Id,
            CurrentFrame = CurrentFrame,
            CurrentPlayer = CurrentPlayer == null ? null : Players.IndexOf(CurrentPlayer),
            IsEnded = IsEnded,
            IsInProgress = IsInProgress,
            Players = Players.Select(p => p.GetState()).ToList()
        };
    }

    #region Message Handling

    public void Receive(RequestAddPlayerMessage message)
    {
        if (message.Player != null)
        {
            AddPlayer(message.Player);
        }
    }

    /// <summary>
    /// Resets the game to a started or not started state
    /// </summary>
    public void Receive(RequestGameResetMessage resetMessage)
    {
        IsInProgress = false;
        IsEnded = false;

        CurrentFrame = 1;

        if (resetMessage.ClearPlayers)
        {
            CurrentPlayer = null;
            Players.Clear();
        }
        else
        {
            CurrentPlayer = Players[0];

            foreach (var player in Players)
            {
                player.Reset();
            }

            UpdateCurrentFrame();
        }

        _events.Send(new Game.Reset(GetState(), resetMessage.ClearPlayers), default(GameToken));
    }

    public void Receive(RequestGameLoadMessage message)
    {
        IsInProgress = message.State.IsInProgress;
        IsEnded = message.State.IsEnded;
        CurrentFrame = message.State.CurrentFrame;

        Players.Clear();

        foreach(var player in message.State.Players)
        {
            Players.Add(BowlingPlayer.FromState(player));
        }

        if (message.State.CurrentPlayer != null)
        {
            CurrentPlayer = Players[message.State.CurrentPlayer.Value];
        }

        _events.Send(new Game.Loaded(), default(GameToken));
    }

    public void Receive(Game.Turn message)
    {
        OnPropertyChanged(nameof(CurrentFrameSemanticHint));
    }

    #endregion
}