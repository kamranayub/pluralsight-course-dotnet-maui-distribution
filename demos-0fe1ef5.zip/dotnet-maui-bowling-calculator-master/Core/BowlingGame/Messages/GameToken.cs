﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace BowlingCalculator.BowlingGame.Messages
{
    public struct GameToken : IEquatable<GameToken>
    {
        /// <inheritdoc/>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool Equals(GameToken other)
        {
            return true;
        }

        /// <inheritdoc/>
        public override bool Equals(object? obj)
        {
            return obj is GameToken;
        }

        /// <inheritdoc/>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override int GetHashCode()
        {
            return 0;
        }
    }
}
