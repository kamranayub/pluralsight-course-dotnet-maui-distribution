﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using BowlingCalculator.Resources;
using CommunityToolkit.Mvvm.ComponentModel;

namespace BowlingCalculator.BowlingGame;

public class BowlingPlayer : ObservableObject
{
    private int _score;

    public static BowlingPlayer FromState(PlayerState player)
    {
        var newPlayer = new BowlingPlayer()
        {
            Name = player.Name,
            Score = player.Score
        };

        newPlayer.Frames.Clear();

        foreach (var frame in player.Frames)
        {
            newPlayer.Frames.Add(BowlingFrame.FromState(frame));
        }

        return newPlayer;
    }

    public BowlingPlayer()
    {
        Frames = new ObservableCollection<BowlingFrame>();
        for (var i = 0; i < Constants.Frames; i++)
        {
            var frame = new BowlingFrame() { Index = i };
            Frames.Add(frame);
        }
    }

    public string Name { get; set; }

    public bool IsCurrentTurn => Frames.Any(f => f.IsCurrentFrame);

    public int Score
    {
        get { return _score; }
        set
        {
            if (value == _score) return;
            _score = value;
            OnPropertyChanged();
        }
    }

    private BowlingFrame? LastFramePlayed => Frames.LastOrDefault(f => f.Ball1 != null);

    public string SemanticSummary
    {
        get
        {
            var hintBuilder = new StringBuilder();
            var summaryFrame = Frames.FirstOrDefault(f => f.IsCurrentFrame);
            if (summaryFrame != null)
            {
                hintBuilder.AppendFormat(AppResources.PlayerSemanticSummarySelectPins, summaryFrame.Index + 1);
            }
            else if (LastFramePlayed != null)
            {
                summaryFrame = LastFramePlayed;
                hintBuilder.AppendFormat(AppResources.PlayerSemanticSummaryLastPlayed, LastFramePlayed.Index + 1);
            } 
            else
            {
                hintBuilder.Append(AppResources.PlayerSemanticSummaryNotYetPlayed);
            }

            if (summaryFrame?.Ball1 != null)
            {
                hintBuilder.AppendFormat(AppResources.PlayerSemanticSummaryFirstBall, summaryFrame.Ball1DisplayText);

                if (summaryFrame.Ball2 != null)
                {
                    hintBuilder.AppendFormat(AppResources.PlayerSemanticSummaryOtherBalls, summaryFrame.Ball2DisplayText);
                }

                if (summaryFrame.Ball3 != null)
                {
                    hintBuilder.AppendFormat(AppResources.PlayerSemanticSummaryOtherBalls, summaryFrame.Ball3DisplayText);
                }
            }

            return hintBuilder.ToString();
        }
    }

    public ObservableCollection<BowlingFrame> Frames { get; set; }

    public void Bowl(int currentFrame, int pins)
    {
        Frames[currentFrame - 1].Bowl(pins);        
        OnFramesChanged();
    }

    public int GetScore()
    {
        return Frames.Sum(f => f.GetScore(Frames).GetValueOrDefault());
    }

    public void Reset()
    {
        Score = 0;

        foreach (var frame in Frames)
        {
            frame.Reset();
        }

        OnFramesChanged();
    }

    public void OnFramesChanged()
    {
        OnPropertyChanged(nameof(SemanticSummary));
        OnPropertyChanged(nameof(IsCurrentTurn));
    }


    internal PlayerState GetState()
    {
        return new PlayerState()
        {
            Name = Name,
            Score = Score,
            Frames = Frames.Select(f => f.GetState()).ToList()
        };
    }
}