﻿using CommunityToolkit.Maui.Core;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace BowlingCalculator.ViewModels
{
    public class PinPickerViewModel : BaseViewModel
    {
        private readonly IPopupService _popupService;

        public ObservableCollection<int> Pins { get; set; }

        public ICommand SelectPinsCommand { get; }

        public PinPickerViewModel(IPopupService popupService)
        {
            _popupService = popupService;

            Pins = new ObservableCollection<int>();
            SelectPinsCommand = new RelayCommand<int>(SelectPins);
        }

        public void SetAvailablePins(int pins)
        {
            for (var i = 0; i <= pins; i++)
            {
                Pins.Add(i);
            }
        }

        public void SelectPins(int pins)
        {
            _popupService.ClosePopup(pins);
        }
    }
}
