﻿using BowlingCalculator.Models;
using BowlingCalculator.Resources;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace BowlingCalculator.ViewModels;

public class ChangelogViewModel : BaseViewModel
{

    public ObservableCollection<Release> ReleaseNotes { get; set; }

    public ChangelogViewModel()
    {
        ReleaseNotes = new ObservableCollection<Release>();
    }

    public async Task LoadReleaseNotes()
    {
        var assembly = typeof(ChangelogViewModel).Assembly;
        var releaseFile = assembly.GetManifestResourceStream($"BowlingCalculator.Resources.ReleaseNotes.xml");

        if (releaseFile == null) return;

        // Get language code (en, fr, etc.)
        var languageCode = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
        var releaseDoc = await XDocument.LoadAsync(releaseFile, LoadOptions.None, default);

        if (releaseDoc?.Root == null) return;

        var releases = from rNode in releaseDoc.Root.Descendants()
                       let versionAttr = rNode.Attribute("version")
                       let notes = from notesNode in rNode.Descendants()
                                   let langAttr = notesNode.Attribute("lang")
                                   where langAttr != null && langAttr.Value == languageCode
                                   select notesNode
                       where notes != null &&
                             notes.Any() &&
                             versionAttr != null
                       select
                           new Release()
                           {
                               Version = versionAttr.Value,
                               Notes = notes.First().Value
                           };

        foreach(var release in releases)
        {
            ReleaseNotes.Add(release);
        }
    }
}