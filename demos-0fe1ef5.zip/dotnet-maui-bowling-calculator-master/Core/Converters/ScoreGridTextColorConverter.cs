﻿using BowlingCalculator.Resources;
using System.Globalization;

namespace BowlingCalculator.Converters
{
    public class ScoreGridTextColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {

            var score = value as string;

            if (score == AppResources.SpareText ||
                score == AppResources.StrikeText)
            {
                return Application.Current.RequestedTheme == AppTheme.Dark
                    ? Application.Current.Resources["TertiaryDark"]
                    : Application.Current.Resources["Tertiary"];
            }
            else
            {
                return Application.Current.RequestedTheme == AppTheme.Dark 
                    ? Application.Current.Resources["Secondary"] 
                    : Application.Current.Resources["Primary"];
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
