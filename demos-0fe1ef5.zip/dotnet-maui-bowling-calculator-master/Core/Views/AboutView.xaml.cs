namespace BowlingCalculator.Views;

public partial class AboutView : ContentPage
{
	public AboutView(AboutViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        ((AboutViewModel)BindingContext).HandleRequestedThemeChanged(Application.Current!.RequestedTheme);
        Application.Current!.RequestedThemeChanged += Current_RequestedThemeChanged;
    }

    private void Current_RequestedThemeChanged(object? sender, AppThemeChangedEventArgs e)
    {
        ((AboutViewModel)BindingContext).HandleRequestedThemeChanged(e.RequestedTheme);
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();

        Application.Current!.RequestedThemeChanged -= Current_RequestedThemeChanged;
    }

}