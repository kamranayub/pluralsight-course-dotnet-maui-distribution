namespace BowlingCalculator.Views;

public partial class GameView : ContentPage
{
    public GameView(GameViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
        viewModel.Game.PropertyChanged += Game_PropertyChanged;
    }

    private void Game_PropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        var game = sender as Bowling;
        var players = (CollectionView)FindByName("Players");

        if (game?.CurrentPlayer != null && e.PropertyName == nameof(game.CurrentPlayer))
        {
            players.ScrollTo(game.CurrentPlayer);
        }

        if (game?.CurrentPlayer != null && e.PropertyName == nameof(game.CurrentFrameSemanticHint))
        {
            
            var elements = (List<IVisualTreeElement>)players.GetVisualTreeDescendants();
            var scoreboards = elements.OfType<IView>().Where(v => v.AutomationId == "Scoreboard").ToList();
            var scoreboard = scoreboards.ElementAtOrDefault(game.Players.IndexOf(game.CurrentPlayer));

            Task.Delay(100).ContinueWith((task) =>
            {
                if (scoreboard != null)
                {
                    scoreboard.SetSemanticFocus();
                }
            });
        }
    }

    //private void PlayerScoreboard_Loaded(object sender, EventArgs e)
    //{

    //}
}