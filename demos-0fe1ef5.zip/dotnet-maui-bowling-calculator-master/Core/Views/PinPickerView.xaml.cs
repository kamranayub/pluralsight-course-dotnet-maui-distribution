using BowlingCalculator.ViewModels;
using CommunityToolkit.Maui.Views;

namespace BowlingCalculator.Views;

public partial class PinPickerView : Popup
{
	public PinPickerView(PinPickerViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
}