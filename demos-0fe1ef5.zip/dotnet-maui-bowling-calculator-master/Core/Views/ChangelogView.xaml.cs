namespace BowlingCalculator.Views;

public partial class ChangelogView : ContentPage
{
	public ChangelogView(ChangelogViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();

		((ChangelogViewModel)BindingContext).LoadReleaseNotes().Wait();
    }
}