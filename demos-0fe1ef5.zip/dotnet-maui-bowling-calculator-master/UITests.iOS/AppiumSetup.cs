﻿using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.iOS;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.Appium.Windows;
using UITests;

[assembly: AssemblyFixture(typeof(AppiumFixture))]

namespace UITests;

public class AppiumFixture : IDisposable
{
    private readonly AppiumDriver? session;
    private readonly AppiumLocalService? service;

    public AppiumDriver App => session ?? throw new NullReferenceException("AppiumDriver is null");

    public string PackageId => "com.kamranayub.bowlingcalculator";

    public AppiumFixture()
    {
        try
        {
            // If you started an Appium server manually, make sure to comment out the next line
            // This line starts a local Appium server for you as part of the test run
            service = AppiumServerHelper.StartAppiumLocalServer();

            var iOSOptions = new AppiumOptions
            {
                // Specify XCUITest as the driver, typically don't need to change this
                AutomationName = "XCUITest",
                // Always iOS for iOS
                PlatformName = "iOS",
                // The full path to the .app file to test or the bundle id if the app is already installed on the device
                App = PackageId
            };

            // SIMULATOR SETUP
                
            // iOS Version
            iOSOptions.PlatformVersion = "18.2";
            // Don't specify if you don't want a specific device
            iOSOptions.DeviceName = "iPhone 16 Pro";
            
            // END SIMULATOR SETUP

            // REAL DEVICE SETUP
            // https://appium.github.io/appium-xcuitest-driver/latest/preparation/real-device-config/
            // https://appium.github.io/appium-xcuitest-driver/latest/preparation/prov-profile-basic-auto/
            // iOSOptions.AddAdditionalAppiumOption("udid", "1bc340d67fe296c8b6b856f15c4daa932edb91e7");
            // iOSOptions.AddAdditionalAppiumOption("xcodeConfigFile", "/Users/kamranicus/.xcconfig");
            // iOSOptions.AddAdditionalAppiumOption("allowProvisioningDeviceRegistration", "true");
            // iOSOptions.AddAdditionalAppiumOption("showXcodeLog", "true");
            // END REAL DEVICE SETUP

            // Note there are many more options that you can use to influence the app under test according to your needs

            session = new IOSDriver(iOSOptions);
        } 
        catch
        {
            Dispose();

            throw;
        }

        Assert.NotNull(session);
    }

    public void Dispose()
    {
        session?.Quit();

        // If an Appium server was started locally above, make sure we clean it up here
        AppiumServerHelper.DisposeAppiumLocalServer(service);        
    }
}